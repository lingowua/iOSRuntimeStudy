#include <stdio.h>
#include "base.h"

int base1() { return 1; }
int base2() { return 2; }

