

#include <stdbool.h> 

__attribute__((weak)) bool bar1()
{
	return false;
}

