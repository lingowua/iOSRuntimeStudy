

const char* foo()
{
    return "foo";
}