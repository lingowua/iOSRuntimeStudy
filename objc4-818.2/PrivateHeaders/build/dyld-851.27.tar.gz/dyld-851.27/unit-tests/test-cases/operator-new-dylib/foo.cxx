
#include <stdlib.h>
#include <new>





char* foo()
{
	return new char[24];
}

